"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Download, FileSpreadsheet } from "lucide-react"
import * as XLSX from "xlsx"

export function ExcelTemplateGenerator() {
  const generateTemplate = () => {
    try {
      const templateData = [
        {
          "Numéro Chèque": "001234",
          "Logo/Nom Compagnie": "ENTREPRISE EXEMPLE SARL",
          "Série Gauche": "A001",
          "Chèque N° Gauche": "001234",
          Date: "15/08/2025",
          "À l'ordre de": "FOURNISSEUR EXEMPLE",
          Objet: "Paiement facture N°2025-001",
          Montant: "1,500.00 FCFA",
          "Série Droite": "A001",
          "Payer contre ce chèque": "MILLE CINQ CENTS FRANCS CFA",
          "À l'ordre de (droite)": "FOURNISSEUR EXEMPLE",
          "Payable à": "DAKAR",
          "Lieu (A)": "DAKAR",
          "Date (Le)": "15/08/2025",
        },
        {
          "Numéro Chèque": "001235",
          "Logo/Nom Compagnie": "ENTREPRISE EXEMPLE SARL",
          "Série Gauche": "A001",
          "Chèque N° Gauche": "001235",
          Date: "16/08/2025",
          "À l'ordre de": "PRESTATAIRE SERVICE",
          Objet: "Honoraires consultation",
          Montant: "750.00 FCFA",
          "Série Droite": "A001",
          "Payer contre ce chèque": "SEPT CENT CINQUANTE FRANCS CFA",
          "À l'ordre de (droite)": "PRESTATAIRE SERVICE",
          "Payable à": "THIÈS",
          "Lieu (A)": "THIÈS",
          "Date (Le)": "16/08/2025",
        },
      ]

      const worksheet = XLSX.utils.json_to_sheet(templateData)

      const columnWidths = [
        { wch: 15 }, // Numéro Chèque
        { wch: 25 }, // Logo/Nom Compagnie
        { wch: 12 }, // Série Gauche
        { wch: 18 }, // Chèque N° Gauche
        { wch: 12 }, // Date
        { wch: 25 }, // À l'ordre de
        { wch: 30 }, // Objet
        { wch: 15 }, // Montant
        { wch: 12 }, // Série Droite
        { wch: 35 }, // Payer contre ce chèque
        { wch: 25 }, // À l'ordre de (droite)
        { wch: 15 }, // Payable à
        { wch: 12 }, // Lieu (A)
        { wch: 12 }, // Date (Le)
      ]
      worksheet["!cols"] = columnWidths

      const workbook = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(workbook, worksheet, "Modèle Chèques")

      const instructionsData = [
        { Colonne: "Numéro Chèque", Description: "Numéro unique du chèque (obligatoire)", Exemple: "001234" },
        { Colonne: "Logo/Nom Compagnie", Description: "Nom de votre entreprise", Exemple: "ENTREPRISE EXEMPLE SARL" },
        { Colonne: "Série Gauche", Description: "Code série du carnet", Exemple: "A001" },
        { Colonne: "Chèque N° Gauche", Description: "Numéro du chèque (même que Numéro Chèque)", Exemple: "001234" },
        { Colonne: "Date", Description: "Date d'émission (JJ/MM/AAAA)", Exemple: "15/08/2025" },
        { Colonne: "À l'ordre de", Description: "Nom du bénéficiaire", Exemple: "FOURNISSEUR EXEMPLE" },
        { Colonne: "Objet", Description: "Motif du paiement", Exemple: "Paiement facture N°2025-001" },
        { Colonne: "Montant", Description: "Montant en chiffres avec devise", Exemple: "1,500.00 FCFA" },
        { Colonne: "Série Droite", Description: "Code série (même que Série Gauche)", Exemple: "A001" },
        {
          Colonne: "Payer contre ce chèque",
          Description: "Montant en lettres",
          Exemple: "MILLE CINQ CENTS FRANCS CFA",
        },
        {
          Colonne: "À l'ordre de (droite)",
          Description: "Bénéficiaire (même que À l'ordre de)",
          Exemple: "FOURNISSEUR EXEMPLE",
        },
        { Colonne: "Payable à", Description: "Lieu de paiement", Exemple: "DAKAR" },
        { Colonne: "Lieu (A)", Description: "Lieu d'émission", Exemple: "DAKAR" },
        { Colonne: "Date (Le)", Description: "Date d'émission (même que Date)", Exemple: "15/08/2025" },
      ]

      const instructionsSheet = XLSX.utils.json_to_sheet(instructionsData)
      instructionsSheet["!cols"] = [{ wch: 25 }, { wch: 40 }, { wch: 25 }]
      XLSX.utils.book_append_sheet(workbook, instructionsSheet, "Instructions")

      const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" })
      const blob = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      })

      const url = window.URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = "modele_cheques.xlsx"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(url)

      console.log("[v0] Excel template generated successfully")
    } catch (error) {
      console.error("[v0] Error generating Excel template:", error)
    }
  }

  return (
    <Card className="border-2 border-blue-200 bg-blue-50/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-blue-800">
          <FileSpreadsheet className="h-6 w-6" />
          Modèle Excel
        </CardTitle>
        <CardDescription className="text-blue-700">
          Téléchargez le modèle Excel avec la structure requise pour vos chèques
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Button onClick={generateTemplate} className="w-full bg-blue-600 hover:bg-blue-700 text-white" size="lg">
          <Download className="h-5 w-5 mr-2" />
          Télécharger le Modèle Excel
        </Button>
        <div className="mt-4 p-4 bg-blue-100 rounded-lg">
          <h4 className="font-semibold text-blue-800 mb-2">Structure du fichier :</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Numéro Chèque (obligatoire)</li>
            <li>• Logo/Nom Compagnie</li>
            <li>• Série, Date, Bénéficiaire</li>
            <li>• Objet et Montant</li>
            <li>• Lieu de paiement et d'émission</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
