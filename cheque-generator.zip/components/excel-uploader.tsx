"use client"

import type React from "react"
import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import type { ChequeData } from "@/types/cheque"
import { ExcelTemplateGenerator } from "@/components/excel-template-generator"
import * as XLSX from "xlsx"

interface ExcelUploaderProps {
  onDataLoaded: (data: ChequeData[]) => void
}

export function ExcelUploader({ onDataLoaded }: ExcelUploaderProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)

  const handleFileUpload = useCallback(
    async (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0]
      if (!file) return

      setIsLoading(true)
      setError(null)
      setFileName(file.name)

      try {
        const arrayBuffer = await file.arrayBuffer()
        const workbook = XLSX.read(arrayBuffer, { type: "array" })
        const sheetName = workbook.SheetNames[0]
        const worksheet = workbook.Sheets[sheetName]
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 })

        const chequeData: ChequeData[] = []

        for (let i = 1; i < jsonData.length; i++) {
          const row = jsonData[i] as any[]
          if (row.length === 0 || !row[0]) continue

          const cheque: ChequeData = {
            numeroGauche: row[0]?.toString() || "",
            logoCompany: row[1]?.toString() || "",
            serieGauche: row[2]?.toString() || "",
            chequeNoGauche: row[3]?.toString() || row[0]?.toString() || "",
            dateGauche: row[4]?.toString() || "",
            ordre: row[5]?.toString() || "",
            objet: row[6]?.toString() || "",
            montantGauche: row[7]?.toString() || "",
            serieDroite: row[8]?.toString() || row[2]?.toString() || "",
            payerContreCeCheque: row[9]?.toString() || "",
            aLordreDe: row[10]?.toString() || row[5]?.toString() || "",
            payableA: row[11]?.toString() || "",
            a: row[12]?.toString() || "",
            le: row[13]?.toString() || row[4]?.toString() || "",
            numeroPositions: {
              pos1: row[0]?.toString() || "",
              pos2: row[0]?.toString() || "",
              pos3: row[0]?.toString() || "",
            },
          }

          chequeData.push(cheque)
        }

        onDataLoaded(chequeData)
      } catch (err) {
        setError("Erreur lors de la lecture du fichier Excel. Vérifiez le format du fichier.")
        console.error("Excel parsing error:", err)
      } finally {
        setIsLoading(false)
      }
    },
    [onDataLoaded],
  )

  return (
    <div className="space-y-8">
      <ExcelTemplateGenerator />

      <Card className="border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-emerald-800 text-lg">
            <Upload className="h-6 w-6" />
            Charger le Fichier Excel
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label htmlFor="excel-file" className="text-base font-semibold text-slate-700">
              Sélectionnez votre fichier Excel
            </Label>

            <div className="relative">
              <div className="flex items-center gap-4">
                <div className="flex-1 relative">
                  <Input
                    id="excel-file"
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleFileUpload}
                    disabled={isLoading}
                    className="h-14 text-base border-2 border-emerald-300 focus:border-emerald-500 bg-white file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-emerald-100 file:text-emerald-700 hover:file:bg-emerald-200"
                  />
                </div>
                <Button
                  disabled={isLoading}
                  size="lg"
                  className="px-8 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  {isLoading ? (
                    <div className="animate-spin h-5 w-5 border-2 border-current border-t-transparent rounded-full" />
                  ) : (
                    <>
                      <Upload className="h-5 w-5 mr-2" />
                      Charger
                    </>
                  )}
                </Button>
              </div>
            </div>

            {fileName && (
              <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl shadow-sm">
                <div className="p-2 bg-green-100 rounded-full">
                  <CheckCircle2 className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="font-semibold text-green-800">Fichier chargé avec succès !</p>
                  <p className="text-sm text-green-700">{fileName}</p>
                </div>
              </div>
            )}

            {error && (
              <Alert variant="destructive" className="border-2">
                <AlertCircle className="h-5 w-5" />
                <AlertDescription className="text-base font-medium">{error}</AlertDescription>
              </Alert>
            )}
          </div>

          <Card className="bg-gradient-to-r from-slate-50 to-gray-50 border-2 border-slate-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-slate-800 text-base flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5" />
                Structure Excel Requise
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <p className="font-semibold text-slate-700">Colonnes A-E :</p>
                  <ul className="text-slate-600 space-y-1 ml-4">
                    <li>• Numéro Chèque (obligatoire)</li>
                    <li>• Logo/Nom Compagnie</li>
                    <li>• Série Gauche</li>
                    <li>• Chèque N° Gauche</li>
                    <li>• Date</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <p className="font-semibold text-slate-700">Colonnes F-N :</p>
                  <ul className="text-slate-600 space-y-1 ml-4">
                    <li>• À l'ordre de</li>
                    <li>• Objet</li>
                    <li>• Montant</li>
                    <li>• Série Droite</li>
                    <li>• Payer contre ce chèque</li>
                    <li>• Payable à, Lieu, Date</li>
                  </ul>
                </div>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-sm text-blue-800 font-medium flex items-center gap-2">
                  <FileSpreadsheet className="h-4 w-4" />💡 Conseil : Utilisez le modèle Excel ci-dessus pour garantir
                  la compatibilité parfaite
                </p>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  )
}
