"use client"

import { useEffect, useRef } from "react"
import type { ChequeData } from "@/types/cheque"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Download, Printer, Eye } from "lucide-react"
import jsPDF from "jspdf"

interface ChequePreviewProps {
  chequeData: ChequeData
}

export function ChequePreview({ chequeData }: ChequePreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const chequeImageUrl = "/images/cheque-template.jpg"

  const positions = {
    numeroGauche: { x: 243, y: 43, style: { color: "#dc2626", fontWeight: "bold", fontSize: "18px" } },
    logoRouge: { x: 632, y: 111, style: { fontSize: "16px" } },
    serieGauche: { x: 227, y: 128, style: { fontSize: "16px" } },
    chequeNoGauche: { x: 260, y: 172, style: { fontSize: "16px" } },
    dateGauche: { x: 200, y: 220, style: { fontSize: "16px" } },
    ordreGauche: { x: 213, y: 266, style: { fontSize: "16px" } },
    objetGauche: { x: 196, y: 330, style: { fontSize: "16px" } },
    montantGauche: { x: 234, y: 499, style: { fontSize: "18px", fontWeight: "bold" } },
    serieDroite: { x: 943, y: 154, style: { fontSize: "16px" } },
    payerContreCeCheque: { x: 760, y: 227, style: { fontSize: "16px" } },
    aLordreDe: { x: 632, y: 320, style: { fontSize: "16px" } },
    payableA: { x: 621, y: 500, style: { fontSize: "16px" } },
    a: { x: 1085, y: 424, style: { fontSize: "16px" } },
    le: { x: 1268, y: 422, style: { fontSize: "16px" } },
    numeroPos1: { x: 937, y: 101, style: { color: "#dc2626", fontWeight: "bold", fontSize: "18px" } },
    numeroPos2: { x: 568, y: 573, style: { color: "#dc2626", fontWeight: "bold", fontSize: "18px" } },
    numeroPos3: { x: 1009, y: 166, style: { color: "#dc2626", fontWeight: "bold", fontSize: "18px" } },
  }

  const drawCheque = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const img = new Image()
    img.crossOrigin = "anonymous"
    img.onload = () => {
      canvas.width = img.width
      canvas.height = img.height

      ctx.drawImage(img, 0, 0)
      ctx.textAlign = "left"
      ctx.textBaseline = "top"

      const drawText = (text: string, position: any, style: any = {}) => {
        ctx.fillStyle = style.color || "#000000"
        const fontSize = Number.parseInt(style.fontSize || "16px")
        const fontWeight = style.fontWeight || "normal"
        ctx.font = `${fontWeight} ${fontSize}px Arial`
        ctx.fillText(text, position.x, position.y)
      }

      drawText(chequeData.numeroGauche, positions.numeroGauche, positions.numeroGauche.style)
      drawText(chequeData.logoCompany, positions.logoRouge, positions.logoRouge.style)
      drawText(chequeData.serieGauche, positions.serieGauche, positions.serieGauche.style)
      drawText(chequeData.chequeNoGauche, positions.chequeNoGauche, positions.chequeNoGauche.style)
      drawText(chequeData.dateGauche, positions.dateGauche, positions.dateGauche.style)
      drawText(chequeData.ordre, positions.ordreGauche, positions.ordreGauche.style)
      drawText(chequeData.objet, positions.objetGauche, positions.objetGauche.style)
      drawText(chequeData.montantGauche, positions.montantGauche, positions.montantGauche.style)
      drawText(chequeData.serieDroite, positions.serieDroite, positions.serieDroite.style)
      drawText(chequeData.payerContreCeCheque, positions.payerContreCeCheque, positions.payerContreCeCheque.style)
      drawText(chequeData.aLordreDe, positions.aLordreDe, positions.aLordreDe.style)
      drawText(chequeData.payableA, positions.payableA, positions.payableA.style)
      drawText(chequeData.a, positions.a, positions.a.style)
      drawText(chequeData.le, positions.le, positions.le.style)
      drawText(chequeData.numeroPositions.pos1, positions.numeroPos1, positions.numeroPos1.style)
      drawText(chequeData.numeroPositions.pos2, positions.numeroPos2, positions.numeroPos2.style)
      drawText(chequeData.numeroPositions.pos3, positions.numeroPos3, positions.numeroPos3.style)
    }

    img.src = chequeImageUrl
  }

  const generatePDF = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const pdf = new jsPDF({
      orientation: "landscape",
      unit: "mm",
      format: "a4",
    })

    const imgData = canvas.toDataURL("image/png")
    const imgWidth = 297
    const imgHeight = (canvas.height * imgWidth) / canvas.width

    pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight)
    pdf.save(`cheque_${chequeData.numeroGauche}.pdf`)
  }

  useEffect(() => {
    drawCheque()
  }, [chequeData])

  return (
    <div className="space-y-8">
      <Card className="border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white shadow-xl">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-3 text-emerald-800 text-xl">
            <Eye className="h-6 w-6" />
            Prévisualisation du Chèque
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-white rounded-xl p-6 shadow-inner border-2 border-gray-100">
            <canvas
              ref={canvasRef}
              className="max-w-full h-auto border-2 border-emerald-200 rounded-lg shadow-lg"
              style={{ maxHeight: "600px" }}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-4 justify-center">
        <Button
          onClick={generatePDF}
          size="lg"
          className="flex items-center gap-3 px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
        >
          <Download className="h-5 w-5" />
          Télécharger PDF
        </Button>
        <Button
          variant="outline"
          size="lg"
          className="flex items-center gap-3 px-8 py-3 border-2 border-emerald-600 text-emerald-700 hover:bg-emerald-50 font-semibold shadow-lg hover:shadow-xl transition-all duration-200 bg-transparent"
        >
          <Printer className="h-5 w-5" />
          Imprimer
        </Button>
      </div>

      <Card className="bg-gradient-to-r from-slate-50 to-gray-50 border-2 border-slate-200 shadow-lg">
        <CardHeader>
          <CardTitle className="text-slate-800 text-lg font-serif">Résumé des Données</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
              <span className="text-sm font-medium text-slate-500 block mb-1">Numéro de Chèque</span>
              <span className="text-xl font-bold text-red-600">{chequeData.numeroGauche}</span>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
              <span className="text-sm font-medium text-slate-500 block mb-1">Série</span>
              <span className="text-lg font-semibold text-slate-800">{chequeData.serieGauche}</span>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
              <span className="text-sm font-medium text-slate-500 block mb-1">À l'ordre de</span>
              <span className="text-lg font-semibold text-slate-800">{chequeData.ordre}</span>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
              <span className="text-sm font-medium text-slate-500 block mb-1">Montant</span>
              <span className="text-xl font-bold text-emerald-600">{chequeData.montantGauche}</span>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
              <span className="text-sm font-medium text-slate-500 block mb-1">Date</span>
              <span className="text-lg font-semibold text-slate-800">{chequeData.dateGauche}</span>
            </div>
            <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
              <span className="text-sm font-medium text-slate-500 block mb-1">Objet</span>
              <span className="text-lg font-semibold text-slate-800">{chequeData.objet}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
