"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { FileSpreadsheet, Download, Eye, CheckCircle, Upload, Sparkles } from "lucide-react"
import { ExcelUploader } from "@/components/excel-uploader"
import { ChequePreview } from "@/components/cheque-preview"
import type { ChequeData } from "@/types/cheque"

export default function Home() {
  const [chequeData, setChequeData] = useState<ChequeData[]>([])
  const [selectedCheque, setSelectedCheque] = useState<ChequeData | null>(null)
  const [showPreview, setShowPreview] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)

  const handleDataLoaded = (data: ChequeData[]) => {
    setChequeData(data)
    if (data.length > 0) {
      setSelectedCheque(data[0])
      setCurrentStep(2)
    }
  }

  const handlePreview = () => {
    setShowPreview(true)
    setCurrentStep(3)
  }

  const handleGeneratePDF = () => {
    if (selectedCheque) {
      // Trigger PDF generation directly from the preview component
      const canvas = document.querySelector("canvas")
      if (canvas) {
        const link = document.createElement("a")
        link.download = `cheque_${selectedCheque.numeroGauche}.png`
        link.href = canvas.toDataURL()
        link.click()
      }
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-emerald-100">
      <div className="bg-white border-b-2 border-emerald-100 shadow-lg">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-4 mb-6">
              <div className="p-4 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl shadow-xl">
                <Sparkles className="h-10 w-10 text-white" />
              </div>
              <h1 className="text-5xl font-serif font-bold bg-gradient-to-r from-emerald-700 via-emerald-800 to-emerald-900 bg-clip-text text-transparent">
                Générateur de Chèques
              </h1>
            </div>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              Plateforme professionnelle pour la génération automatique de chèques 
            </p>
          </div>

          <div className="flex justify-center items-center space-x-6 mb-6">
            <div
              className={`flex items-center space-x-4 px-6 py-3 rounded-full transition-all duration-300 ${
                currentStep >= 1 ? "bg-emerald-600 text-white shadow-lg scale-105" : "bg-slate-200 text-slate-500"
              }`}
            >
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  currentStep > 1 ? "bg-white/20" : ""
                }`}
              >
                {currentStep > 1 ? <CheckCircle className="w-6 h-6" /> : <Upload className="w-6 h-6" />}
              </div>
              <span className="font-semibold text-lg">Import Excel</span>
            </div>
            <div
              className={`w-20 h-2 rounded-full transition-all duration-300 ${
                currentStep >= 2 ? "bg-emerald-600" : "bg-slate-300"
              }`}
            />
            <div
              className={`flex items-center space-x-4 px-6 py-3 rounded-full transition-all duration-300 ${
                currentStep >= 2 ? "bg-emerald-600 text-white shadow-lg scale-105" : "bg-slate-200 text-slate-500"
              }`}
            >
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  currentStep > 2 ? "bg-white/20" : ""
                }`}
              >
                {currentStep > 2 ? <CheckCircle className="w-6 h-6" /> : <FileSpreadsheet className="w-6 h-6" />}
              </div>
              <span className="font-semibold text-lg">Configuration</span>
            </div>
            <div
              className={`w-20 h-2 rounded-full transition-all duration-300 ${
                currentStep >= 3 ? "bg-emerald-600" : "bg-slate-300"
              }`}
            />
            <div
              className={`flex items-center space-x-4 px-6 py-3 rounded-full transition-all duration-300 ${
                currentStep >= 3 ? "bg-emerald-600 text-white shadow-lg scale-105" : "bg-slate-200 text-slate-500"
              }`}
            >
              <div className="w-10 h-10 rounded-full flex items-center justify-center">
                <Eye className="w-6 h-6" />
              </div>
              <span className="font-semibold text-lg">Génération</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card className="border-2 border-primary/20 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-primary/5 to-secondary/5">
                <CardTitle className="flex items-center gap-3 text-xl">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <FileSpreadsheet className="h-6 w-6 text-primary" />
                  </div>
                  Import des Données Excel
                </CardTitle>
                <CardDescription className="text-base">
                  Uploadez votre fichier Excel contenant les informations des chèques à générer
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <ExcelUploader onDataLoaded={handleDataLoaded} />
              </CardContent>
            </Card>

            {chequeData.length > 0 && (
              <Card className="border-2 border-secondary/20 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-secondary/5 to-primary/5">
                  <CardTitle className="flex items-center gap-3 text-xl">
                    <div className="p-2 bg-secondary/10 rounded-lg">
                      <CheckCircle className="h-6 w-6 text-secondary" />
                    </div>
                    Configuration du Chèque
                  </CardTitle>
                  <CardDescription className="text-base">
                    {chequeData.length} chèque(s) chargé(s) avec succès
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    <div>
                      <Label htmlFor="cheque-select" className="text-base font-medium">
                        Sélectionner un chèque à prévisualiser
                      </Label>
                      <select
                        id="cheque-select"
                        className="w-full mt-2 p-3 border-2 border-input rounded-lg bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 transition-colors"
                        value={selectedCheque?.numeroGauche || ""}
                        onChange={(e) => {
                          const cheque = chequeData.find((c) => c.numeroGauche === e.target.value)
                          setSelectedCheque(cheque || null)
                        }}
                      >
                        {chequeData.map((cheque, index) => (
                          <option key={index} value={cheque.numeroGauche}>
                            Chèque N° {cheque.numeroGauche} - {cheque.ordre}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex gap-3">
                      <Button onClick={handlePreview} className="flex-1 h-12 text-base font-medium">
                        <Eye className="h-5 w-5 mr-2" />
                        Prévisualiser
                      </Button>
                      <Button
                        onClick={handleGeneratePDF}
                        variant="secondary"
                        className="flex-1 h-12 text-base font-medium"
                      >
                        <Download className="h-5 w-5 mr-2" />
                        Générer PDF
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            {showPreview && selectedCheque ? (
              <Card className="border-2 border-accent/20 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-accent/5 to-primary/5">
                  <CardTitle className="flex items-center gap-3 text-xl">
                    <div className="p-2 bg-accent/10 rounded-lg">
                      <Eye className="h-6 w-6 text-accent" />
                    </div>
                    Prévisualisation du Chèque
                  </CardTitle>
                  <CardDescription className="text-base">
                    Chèque N° {selectedCheque.numeroGauche} - Vérifiez les données avant génération
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <ChequePreview chequeData={selectedCheque} />
                </CardContent>
              </Card>
            ) : (
              <Card className="border-2 border-dashed border-muted-foreground/20">
                <CardContent className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="p-4 bg-muted/50 rounded-full mb-4">
                    <Eye className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-serif font-bold text-muted-foreground mb-2">Prévisualisation</h3>
                  <p className="text-muted-foreground">
                    Uploadez un fichier Excel et sélectionnez un chèque pour voir la prévisualisation
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
