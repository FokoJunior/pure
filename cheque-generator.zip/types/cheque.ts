export interface ChequeData {
  numeroGauche: string
  logoCompany: string
  serieGauche: string
  chequeNoGauche: string
  dateGauche: string
  ordre: string
  objet: string
  montantGauche: string
  serieDroite: string
  payerContreCeCheque: string
  aLordreDe: string
  payableA: string
  a: string
  le: string
  numeroPositions: {
    pos1: string
    pos2: string
    pos3: string
  }
}
